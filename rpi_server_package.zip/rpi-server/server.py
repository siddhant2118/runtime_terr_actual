#!/usr/bin/env python3
"""
Sheldon Rover - Raspberry Pi Server
Serves the character page with audio files over HTTP.
Polls ESP32 for events and stores them for the web page.

Usage:
    python3 server.py [--port 8080] [--esp32-ip 192.168.4.1]
"""

import http.server
import socketserver
import json
import threading
import time
import os
import argparse
from urllib.parse import parse_qs, urlparse
import urllib.request
import urllib.error

# Configuration
PORT = 8080
ESP32_IP = "192.168.4.1"
POLL_INTERVAL = 0.3  # seconds

# Global state
current_event = ""
event_lock = threading.Lock()


class SheldonHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP request handler for Sheldon Rover"""
    
    def __init__(self, *args, **kwargs):
        # Serve files from static directory
        super().__init__(*args, directory="static", **kwargs)
    
    def do_GET(self):
        """Handle GET requests"""
        parsed = urlparse(self.path)
        
        if parsed.path == "/event":
            self.handle_get_event()
        elif parsed.path == "/status":
            self.handle_status()
        elif parsed.path == "/" or parsed.path == "/index.html":
            self.serve_character_page()
        elif parsed.path == "/remote":
            self.serve_remote_page()
        else:
            # Serve static files (audio, etc.)
            super().do_GET()
    
    def do_POST(self):
        """Handle POST requests"""
        parsed = urlparse(self.path)
        
        if parsed.path == "/event":
            self.handle_post_event()
        elif parsed.path == "/stop":
            self.handle_stop()
        elif parsed.path == "/mode":
            self.handle_proxy(parsed.path)
        elif parsed.path == "/say":
            self.handle_proxy(parsed.path)
        elif parsed.path == "/move":
            self.handle_proxy(parsed.path)
        else:
            self.send_error(404)
    
    def do_OPTIONS(self):
        """Handle CORS preflight"""
        self.send_response(204)
        self.send_cors_headers()
        self.end_headers()
    
    def send_cors_headers(self):
        """Add CORS headers"""
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
    
    def handle_get_event(self):
        """Return current event and clear it"""
        global current_event
        with event_lock:
            event = current_event
            current_event = ""
        
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(json.dumps({"event": event}).encode())
    
    def handle_post_event(self):
        """Receive an event"""
        global current_event
        
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode()
        
        try:
            data = json.loads(body)
            event = data.get("event", "")
            with event_lock:
                current_event = event
            print(f"EVENT: {event}")
            
            # Also forward to ESP32 if connected
            try:
                req = urllib.request.Request(
                    f"http://{ESP32_IP}/event",
                    data=body.encode(),
                    headers={"Content-Type": "application/json"},
                    method="POST"
                )
                urllib.request.urlopen(req, timeout=1)
            except:
                pass  # ESP32 not reachable, that's fine
            
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(b'{"ok":true}')
        except:
            self.send_error(400)
    
    def handle_stop(self):
        """Emergency stop"""
        global current_event
        with event_lock:
            current_event = ""
        
        # Forward to ESP32
        try:
            req = urllib.request.Request(
                f"http://{ESP32_IP}/stop",
                method="POST"
            )
            urllib.request.urlopen(req, timeout=1)
        except:
            pass
        
        print("EMERGENCY STOP")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(b'{"ok":true,"stopped":true}')

    def handle_proxy(self, path):
        """Proxy request to ESP32"""
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)
        
        print(f"PROXY {path}")
        
        try:
            req = urllib.request.Request(
                f"http://{ESP32_IP}{path}",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST"
            )
            urllib.request.urlopen(req, timeout=1)
            
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(b'{"ok":true}')
        except Exception as e:
            print(f"Proxy error: {e}")
            self.send_error(502, "ESP32 not reachable")
    
    def handle_status(self):
        """Return server status"""
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(json.dumps({
            "status": "online",
            "server": "rpi",
            "esp32_ip": ESP32_IP
        }).encode())
    
    def serve_character_page(self):
        """Serve the character/voice page"""
        try:
            with open("static/character.html", "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(content)
        except FileNotFoundError:
            self.send_error(404, "character.html not found")
    
    def serve_remote_page(self):
        """Serve the remote control page"""
        try:
            with open("static/remote.html", "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(content)
        except FileNotFoundError:
            self.send_error(404, "remote.html not found")
    
    def log_message(self, format, *args):
        """Custom logging"""
        print(f"[{self.address_string()}] {args[0]}")


def poll_esp32():
    """Background thread to poll ESP32 for events"""
    global current_event
    
    while True:
        try:
            req = urllib.request.Request(f"http://{ESP32_IP}/event")
            with urllib.request.urlopen(req, timeout=1) as resp:
                data = json.loads(resp.read().decode())
                event = data.get("event", "")
                if event:
                    with event_lock:
                        current_event = event
                    print(f"ESP32 EVENT: {event}")
        except:
            pass  # ESP32 not reachable
        
        time.sleep(POLL_INTERVAL)


def main():
    global PORT, ESP32_IP
    
    parser = argparse.ArgumentParser(description="Sheldon Rover RPi Server")
    parser.add_argument("--port", type=int, default=8080, help="Server port")
    parser.add_argument("--esp32-ip", default="192.168.4.1", help="ESP32 IP address")
    parser.add_argument("--no-poll", action="store_true", help="Don't poll ESP32")
    args = parser.parse_args()
    
    PORT = args.port
    ESP32_IP = args.esp32_ip
    
    # Start ESP32 polling thread
    if not args.no_poll:
        poll_thread = threading.Thread(target=poll_esp32, daemon=True)
        poll_thread.start()
        print(f"Polling ESP32 at {ESP32_IP}")
    
    # Start HTTP server
    with socketserver.TCPServer(("", PORT), SheldonHandler) as httpd:
        ip = get_local_ip()
        print(f"\n{'='*50}")
        print(f"Sheldon Rover RPi Server")
        print(f"{'='*50}")
        print(f"Character Page: http://{ip}:{PORT}/")
        print(f"Remote Page:    http://{ip}:{PORT}/remote")
        print(f"{'='*50}\n")
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down...")


def get_local_ip():
    """Get local IP address"""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "localhost"


if __name__ == "__main__":
    main()
