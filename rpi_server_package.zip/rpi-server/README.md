# Sheldon Rover - Raspberry Pi Server

This server runs on a Raspberry Pi to bridge the connection between iPhones and the ESP32, solving the "Mixed Content" issue by serving everything over HTTP.

## Features
- **Serves Character Interface**: `http://<rpi-ip>:8080/`
- **Serves Remote Control**: `http://<rpi-ip>:8080/remote`
- **Hosts Audio Files**: Served locally from RPi (no internet needed)
- **Proxies to ESP32**: Forwards commands to ESP32 (192.168.4.1)

## Setup

1. **Copy Files to RPi**
   Copy the `rpi-server` folder to your Raspberry Pi.

2. **Connect RPi to SheldonRover WiFi**
   Connect your Raspberry Pi to the ESP32's WiFi network (`SheldonRover`).

3. **Run the Server**
   ```bash
   cd rpi-server
   python3 server.py
   ```
   *The server runs on port 8080 by default.*

## Usage

1. **Connect Devices**
   Connect both iPhones to `SheldonRover` WiFi.

2. **Open Character Interface (iPhone 1)**
   Open `http://<rpi-ip>:8080/`
   *Audio will load from the RPi and act as the speaker.*

3. **Open Remote Control (iPhone 2)**
   Open `http://<rpi-ip>:8080/remote`
   *This will control the robot by forwarding commands through the RPi.*

## Troubleshooting
- Ensure RPi is connected to `SheldonRover`.
- Ensure ESP32 is at `192.168.4.1`.
- If audio doesn't play, tap "TAP TO INITIALIZE" first.
